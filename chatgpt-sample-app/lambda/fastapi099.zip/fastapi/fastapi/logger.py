import logging

logger = logging.getLogger("fastapi")
